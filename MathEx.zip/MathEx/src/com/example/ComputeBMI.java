/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;


import java.util.Scanner;
import java.math.*;

public class ComputeBMI {
    public static void main(String[] args)
	{
            double peso = 132.5;
            double altura = 62.5;
            double bmi = (peso / Math.pow(altura, 2)) * 703;
            int redondeado = (int)bmi;
            System.out.println("su bmi redondeado es: " + redondeado);
        }
}
